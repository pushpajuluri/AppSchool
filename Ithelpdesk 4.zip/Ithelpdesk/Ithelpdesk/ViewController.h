//
//  ViewController.h
//  Ithelpdesk
//
//  Created by omniwyse on 01/11/17.
//  Copyright © 2017 omniwyse. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CustomButtonClass.h"


@interface ViewController : UIViewController<UITextFieldDelegate,UIPickerViewDataSource,UIPickerViewDelegate,UIImagePickerControllerDelegate,UIActionSheetDelegate,UINavigationControllerDelegate>

{
    UIImagePickerController *imagePicker;
    UIActionSheet *actionsheet;
    IBOutlet UIImageView *captuerimage;
}


@property (weak, nonatomic) IBOutlet UITextField *txtName;

@property (weak, nonatomic) IBOutlet UITextField *txtMail;
@property (weak, nonatomic) IBOutlet UITextField *txtPhoneNumber;
@property (weak, nonatomic) IBOutlet UITextField *txtLocation;
@property (weak, nonatomic) IBOutlet UITextView *txtMessage;
@property (weak, nonatomic) IBOutlet UITextField *txtSelectItem;
@property (weak, nonatomic) IBOutlet UIPickerView *picker;
@property (strong,nonatomic) NSArray *arrayNo;
@property (weak, nonatomic) IBOutlet UIScrollView *scroll;
@property (weak, nonatomic) IBOutlet UIView *viName;
@property (weak, nonatomic) IBOutlet UIView *viMail;
@property (weak, nonatomic) IBOutlet UIView *viPhoneNumber;
@property (weak, nonatomic) IBOutlet UIView *viLocation;
@property (weak, nonatomic) IBOutlet UIView *viMsg;
@property (weak, nonatomic) IBOutlet UIView *viSelectItem;
@property (strong, nonatomic) IBOutlet UIImageView *imgVerification;
@property (weak, nonatomic) IBOutlet UIButton *btnVerify;

@property (weak, nonatomic) IBOutlet CustomButtonClass *btnName;
@property (weak, nonatomic) IBOutlet CustomButtonClass *btnEmail;
@property (weak, nonatomic) IBOutlet CustomButtonClass *btnPhoneNumber;
@property (weak, nonatomic) IBOutlet CustomButtonClass *btnSelectIteam;
@property (weak, nonatomic) IBOutlet CustomButtonClass *btnLocation;
@property (weak, nonatomic) IBOutlet CustomButtonClass *btnwrite;



@end

