//
//  ViewController.m
//  Ithelpdesk
//
//  Created by omniwyse on 01/11/17.
//  Copyright © 2017 omniwyse. All rights reserved.
//

#import "ViewController.h"
#import "SKPSMTPMessage.h"
#import "NSData+Base64Additions.h"
#import "NSString+FontAwesome.h"
#import "CustomButtonClass.h"
#import "FontAwesomeButton.h"
#import <Firebase.h>
#import <FirebaseAuth/FirebaseAuth.h>
#import "VerifyViewController.h"


@interface ViewController ()<SKPSMTPMessageDelegate>
{
    NSString *filePath;
}

@end

@implementation ViewController



- (void)viewDidLoad {
    [super viewDidLoad];
    [self colors];
    _arrayNo =@[@"laptops",@"desktops"];
    [_txtSelectItem addTarget:self action:@selector(textFieldDidChange:)forControlEvents:UIControlEventEditingChanged];
    [_picker reloadAllComponents];
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(highlightLetter:)];
    tapGesture.numberOfTapsRequired = 1;
    [_txtSelectItem addGestureRecognizer:tapGesture];
    [_txtSelectItem setUserInteractionEnabled:YES];
    _picker.hidden = YES;
    UIActivityIndicatorView *spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    [self.view addSubview:spinner];
    [spinner setFrame:CGRectMake((self.view.frame.size.width/2)-(spinner.frame.size.width/2), (self.view.frame.size.height/2)-(spinner.frame.size.height/2), spinner.frame.size.width, spinner.frame.size.height)];
    
    _imgVerification.image = [UIImage imageNamed: @"ex.png"];
  
}
//picker called method

-(void)textFieldDidChange :(UITextField *)theTextField{
  [_txtSelectItem resignFirstResponder];
     _picker.hidden = NO;
}

- (void)highlightLetter:(UITapGestureRecognizer*)sender {
    [_txtSelectItem resignFirstResponder];
    _picker.hidden = NO;
}



- (IBAction)Submit:(id)sender {
   // [spinner startAnimating];
    NSString *countryCode = [NSString stringWithFormat:@"%d",+91];
    NSString *Name = _txtName.text;
    NSString *phone = [NSString stringWithFormat:@"%@%@",countryCode,_txtPhoneNumber.text];
    NSString *Email = _txtMail.text;
    NSString *location = _txtLocation.text;
    NSString *message = _txtMessage.text;
    NSString *complaint = _txtSelectItem.text;
    
    
    NSLog(@"Start Sending");
    SKPSMTPMessage *emailMessage = [[SKPSMTPMessage alloc] init];
    emailMessage.fromEmail = @"myhelpdeskit@gmail.com"; //sender email address
    emailMessage.toEmail = [NSString stringWithFormat:@"%@",Email];  //receiver email address
    emailMessage.relayHost = @"smtp.gmail.com";
    emailMessage.ccEmail =@"mukesh.kumar@gmail.com";
    //emailMessage.bccEmail =@"your bcc address";
    emailMessage.requiresAuth = YES;
    emailMessage.login = @"myhelpdeskit@gmail.com"; //sender email address
    emailMessage.pass = @"Rangam@5"; //sender email password
    emailMessage.subject =[NSString stringWithFormat:@"%s%@","Complaint:",complaint];
    emailMessage.wantsSecure = YES;
    emailMessage.delegate = self; // you must include <SKPSMTPMessageDelegate> to your class
    NSString *messageBody =[NSString stringWithFormat:@"%s%@%s%s%@%s%s%@%s%s%@","Name:",Name,"\n","Contact number:",phone,"\n","Location:",location,"\n","message:",message];
   
    NSDictionary *plainMsg = [NSDictionary
                              dictionaryWithObjectsAndKeys:@"text/plain",kSKPSMTPPartContentTypeKey,
                              messageBody,kSKPSMTPPartMessageKey,@"8bit",kSKPSMTPPartContentTransferEncodingKey,nil];
   // emailMessage.parts = [NSArray arrayWithObjects:plainMsg,nil];
    
   
    
    
   
    
    
    // NSString *filePath = [[NSBundle mainBundle] pathForResource:@"ex" ofType:@"png"];
     NSData *fileData = [NSData dataWithContentsOfFile:filePath];
     NSDictionary *fileMsg = [NSDictionary dictionaryWithObjectsAndKeys:@"unix-mode=0644;\r\n\timage=\"image.png",kSKPSMTPPartContentTypeKey,@"attachment;\r\n\timage=\"image.png",kSKPSMTPPartContentDispositionKey,[fileData encodeBase64ForData],kSKPSMTPPartMessageKey,@"base64",kSKPSMTPPartContentTransferEncodingKey,nil];
     emailMessage.parts = [NSArray arrayWithObjects:plainMsg,fileMsg,nil]; //including plain msg and attached file msg

    
    
    [emailMessage send];
    
}


#pragma mark- uicolor and border
-(void)colors
{
    
//    [self.btnName setTitleColor:[UIColor colorWithRed:204.0/255.0 green:204.0/255.0 blue:204.0/255.0 alpha:1] andFontsize:20.0 andTitle:FAUser];
//    [self.btnEmail setTitleColor:[UIColor colorWithRed:204.0/255.0 green:204.0/255.0 blue:204.0/255.0 alpha:1] andFontsize:20.0 andTitle:FAUser];
//    [self.btnPhoneNumber setTitleColor:[UIColor colorWithRed:204.0/255.0 green:204.0/255.0 blue:204.0/255.0 alpha:1] andFontsize:20.0 andTitle:FAEnvelopeO];
//    [self.btnSelectIteam setTitleColor:[UIColor colorWithRed:204.0/255.0 green:204.0/255.0 blue:204.0/255.0 alpha:1] andFontsize:20.0 andTitle:FAKey];
//    [self.btnLocation setTitleColor:[UIColor colorWithRed:204.0/255.0 green:204.0/255.0 blue:204.0/255.0 alpha:1] andFontsize:20.0 andTitle:FAKey];
    
    _viName.layer.borderWidth = 1.0f;
    _viName.layer.borderColor = [UIColor colorWithRed:204.0/255.0 green:204.0/255.0 blue:204.0/255.0 alpha:1].CGColor;
    _viName.layer.cornerRadius = 8.0f;
    _viMail.layer.borderWidth = 1.0f;
    _viMail.layer.borderColor = [UIColor colorWithRed:204.0/255.0 green:204.0/255.0 blue:204.0/255.0 alpha:1].CGColor;
    _viMail.layer.cornerRadius = 8.0f;
    _viPhoneNumber.layer.borderWidth = 1.0f;
    _viPhoneNumber.layer.borderColor = [UIColor colorWithRed:204.0/255.0 green:204.0/255.0 blue:204.0/255.0 alpha:1].CGColor;
    _viPhoneNumber.layer.cornerRadius = 8.0f;
    _viLocation.layer.borderWidth = 1.0f;
    _viLocation.layer.borderColor = [UIColor colorWithRed:204.0/255.0 green:204.0/255.0 blue:204.0/255.0 alpha:1].CGColor;
    _viLocation.layer.cornerRadius = 8.0f;
    _viMsg.layer.borderWidth = 1.0f;
    _viMsg.layer.borderColor = [UIColor colorWithRed:204.0/255.0 green:204.0/255.0 blue:204.0/255.0 alpha:1].CGColor;
    _viMsg.layer.cornerRadius = 8.0f;
    _viSelectItem.layer.borderWidth = 1.0f;
    _viSelectItem.layer.borderColor = [UIColor colorWithRed:204.0/255.0 green:204.0/255.0 blue:204.0/255.0 alpha:1].CGColor;
    _viSelectItem.layer.cornerRadius = 8.0f;
  //  [_txtPhoneNumber setKeyboardType:UIKeyboardTypeNumberPad];
//    CALayer *border = [CALayer layer];
//    CGFloat borderWidth = 2;
//    border.borderColor = [UIColor darkGrayColor].CGColor;
//    border.frame = CGRectMake(0, _txtName.frame.size.height - borderWidth, _txtName.frame.size.width, _txtName.frame.size.height);
//    border.borderWidth = borderWidth;
//    [_txtName.layer addSublayer:border];
//    _txtName.layer.masksToBounds = YES;

}
- (IBAction)btnAttachment:(id)sender {
    
    actionsheet = [[UIActionSheet alloc]initWithTitle:@"UPLOAD IMAGE" delegate:self cancelButtonTitle:@"cancel" destructiveButtonTitle:nil otherButtonTitles:@"Gallery",@"Camera", nil];
    [actionsheet showInView:self.view];
    }
-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    if(buttonIndex == 0){
        if([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary]){
            imagePicker = [[UIImagePickerController alloc]init];
            imagePicker.delegate = self;
            imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
            [self presentViewController:imagePicker animated:YES completion:nil];
        
    }
    }
        if([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]){
            imagePicker = [[UIImagePickerController alloc]init];
            imagePicker.delegate = self;
            imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
            [self presentViewController:imagePicker animated:YES completion:nil];
            
        }else{
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"error accessing" message:@"Device does not support" delegate:self cancelButtonTitle:@"Dismiss" otherButtonTitles:nil, nil];
            [alert show];
        }
}

-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info{
    UIImage *image = [info objectForKey:UIImagePickerControllerOriginalImage];
    NSData *pngData = UIImagePNGRepresentation(image);
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsPath = [paths objectAtIndex:0];
    filePath = [documentsPath stringByAppendingPathComponent:@"image.png"];
    [pngData writeToFile:filePath atomically:YES];
    [captuerimage setImage:image];
    [imagePicker dismissViewControllerAnimated:YES completion:nil];
}
-(BOOL) NSStringIsValidEmail:(NSString *)checkString
{
    BOOL stricterFilter = NO;
    NSString *stricterFilterString = @"^[A-Z0-9a-z\\._%+-]+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2,4}$";
    NSString *laxString = @"^.+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2}[A-Za-z]*$";
    NSString *emailRegex = stricterFilter ? stricterFilterString : laxString;
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:checkString];
}
-(void)messageSent:(SKPSMTPMessage *)message{
    NSLog(@"delegate - message sent");
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Message sent." message:nil delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles: nil];
    [alert show];
}

// On Failure
-(void)messageFailed:(SKPSMTPMessage *)message error:(NSError *)error{
    // open an alert with just an OK button
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error!" message:[error localizedDescription] delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles: nil];
    [alert show];
    NSLog(@"delegate - error(%d): %@", [error code], [error localizedDescription]);
}
//scroll view
- (void)viewDidLayoutSubviews
{
    [_scroll setContentSize:CGSizeMake(320, 1000)];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}
// The number of rows of data
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    return _arrayNo.count;
}
// The data to return for the row and component (column) that's being passed in
- (NSString*)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    return _arrayNo[row];
}
-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component{
    _picker.hidden = YES;
    _txtSelectItem.text = _arrayNo[row];
}
// touch

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [_txtSelectItem resignFirstResponder];
    [_txtLocation resignFirstResponder];
    [_txtPhoneNumber resignFirstResponder];
  
    
    return YES;
}
- (BOOL)textView:(UITextView *)_txtMessage shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text {
    if( [text rangeOfCharacterFromSet:[NSCharacterSet newlineCharacterSet]].location == NSNotFound ) {
        return YES;
    }
    
    [_txtMessage resignFirstResponder];
    return NO;
}
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    [self.view endEditing:YES];
}
- (IBAction)verifying:(id)sender {
    NSString *countryCode = [NSString stringWithFormat:@"%s","+91"];
    NSString *phone = [NSString stringWithFormat:@"%@%@",countryCode,_txtPhoneNumber.text];
   // NSString *phone = _txtPhoneNumber.text;
    [[FIRPhoneAuthProvider provider] verifyPhoneNumber:[NSString stringWithFormat:@"%@",phone]
                                            UIDelegate:nil
                                            completion:^(NSString * _Nullable verificationID, NSError * _Nullable error) {
                                                if (error) {
                                                    UIAlertController * erroralertController = [UIAlertController alertControllerWithTitle: @"Error"
                                                                                                                              message: @"enter valid number"
                                                                                                                       preferredStyle:UIAlertControllerStyleAlert];
                                                    [self presentViewController:erroralertController animated:YES completion:nil];
                                                    NSLog(@"Push Error");
                                                    return;
                                                }
                                                NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
                                                [defaults setObject:verificationID forKey:@"authVerificationID"];
//                                                VerifyViewController *rc = [[UIStoryboard storyboardWithName:@"Main" bundle:nil]
//                                                                                    instantiateViewControllerWithIdentifier:@"VerifyViewController"];
//                                                [self.navigationController pushViewController:rc animated:YES];
//                                                
                                                UIAlertController * alertController = [UIAlertController alertControllerWithTitle: @"Verification"
                                                                                                                          message: @"Input 6 digit number"
                                                                                                                   preferredStyle:UIAlertControllerStyleAlert];
                                                [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
                                                    textField.placeholder = @"6 digit number";
                                                    textField.textColor = [UIColor blueColor];
                                                    textField.clearButtonMode = UITextFieldViewModeWhileEditing;
                                                    textField.borderStyle = UITextBorderStyleRoundedRect;
                                                }];
                                                
                                                [alertController addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
                                                    NSArray * textfields = alertController.textFields;
                                                    UITextField * namefield = textfields[0];
                                                    
                                                    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
                                                    NSString *verificationID = [defaults stringForKey:@"authVerificationID"];
                                                    
                                                    FIRAuthCredential *credential = [[FIRPhoneAuthProvider provider]
                                                                                     credentialWithVerificationID:verificationID
                                                                                     verificationCode:namefield.text];
                                                    [[FIRAuth auth] signInWithCredential:credential
                                                                              completion:^(FIRUser *user, NSError *error) {
                                                                                  if (error) {
                                                                                      NSLog(error);
                                                                                      
                                                                                      
                                                                                  }
                                                                                  _imgVerification.image = [UIImage imageNamed: @"verified.png"];
                                                                                  NSLog(@"sucess");
                                                                                  self.btnVerify.enabled = NO;
                                                                                  _btnVerify.alpha = 0;
                                                                              }];
                                                   
                                                    NSLog(@"%@",namefield.text);
                                                    
                                                }]];
                                                [self presentViewController:alertController animated:YES completion:nil];
                                            }];
    
}


@end
