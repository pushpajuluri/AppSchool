//
//  VerifyViewController.h
//  Ithelpdesk
//
//  Created by omniwyse on 03/11/17.
//  Copyright © 2017 omniwyse. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <FirebaseAuth/FirebaseAuth.h>

@interface VerifyViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *txtVerify;
@end
